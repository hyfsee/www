<?php
$localhost="localhost";
$username="root";
$password="huhuto3344";
$db="huhuto";
$conn=mysqli_connect($localhost,$username,$password,$db);
?>